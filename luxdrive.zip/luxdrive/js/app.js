/* ═══════════════════════════════════════════════════
   LUXDRIVE MOTORS — SHARED JAVASCRIPT
   ═══════════════════════════════════════════════════ */

/* ── DATA STORE (simulates backend with localStorage) ── */
const LD = {
  /* seed default cars — v6 = 3 starter cars with easy image URLs */
  initCars() {
    if (localStorage.getItem('ld_seed_ver') === 'v6') return;
    localStorage.removeItem('ld_cars');
    localStorage.setItem('ld_seed_ver', 'v6');

    const seed = [
      {
        id: 'c1',
        brand: 'Lamborghini',
        model: 'Huracán EVO',
        year: 2022,
        km: '4,500',
        fuel: 'Petrol',
        trans: 'LDF 7-Speed',
        power: '631 BHP',
        color: 'Arancio Borealis',
        price: 3.85,
        type: 'supercar',
        badge: 'featured',
        owner: 'admin',
        imgs: [
          'https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80',
          'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?w=800&q=80'
        ],
        desc: 'Pristine condition Huracán EVO. Single owner, full service history at Lamborghini Mumbai. Ceramic coated.',
        city: 'Rajkot, Gujarat',
        testDriveCities: ['Rajkot, Gujarat', 'Ahmedabad, Gujarat']
      },
      {
        id: 'c2',
        brand: 'Ferrari',
        model: 'Roma',
        year: 2021,
        km: '2,800',
        fuel: 'Petrol',
        trans: '8-Speed DCT',
        power: '612 BHP',
        color: 'Rosso Corsa',
        price: 4.20,
        type: 'supercar',
        badge: 'new',
        owner: 'admin',
        imgs: [
          'https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=800&q=80',
          'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?w=800&q=80'
        ],
        desc: 'The beautiful Ferrari Roma in classic Rosso Corsa. Under factory warranty. Extended 7-year maintenance program included.',
        city: 'Dubai, UAE',
        testDriveCities: ['Dubai, UAE']
      },
      {
        id: 'c3',
        brand: 'Rolls-Royce',
        model: 'Ghost EWB',
        year: 2023,
        km: '1,200',
        fuel: 'Petrol',
        trans: 'Automatic',
        power: '563 BHP',
        color: 'Tempest Grey',
        price: 7.95,
        type: 'sedan',
        badge: 'featured',
        owner: 'admin',
        imgs: [
          'https://images.unsplash.com/photo-1631214524020-5e18d9765329?w=800&q=80',
          'https://images.unsplash.com/photo-1631214524231-903ed71f76d9?w=800&q=80'
        ],
        desc: 'Extended Wheelbase Ghost. Bespoke interior with starlight headliner. The pinnacle of automotive luxury.',
        city: 'Ahmedabad, Gujarat',
        testDriveCities: ['Ahmedabad, Gujarat', 'Rajkot, Gujarat']
      },
      {
        id: 'c4',
        brand: 'Porsche',
        model: '911 GT3',
        year: 2022,
        km: '3,100',
        fuel: 'Petrol',
        trans: 'PDK',
        power: '502 BHP',
        color: 'Shark Blue',
        price: 2.90,
        type: 'supercar',
        badge: 'new',
        owner: 'admin',
        imgs: [
          'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?w=800&q=80',
          'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80'
        ],
        desc: 'Track-ready masterpiece. Shark Blue exterior with Weissach package elements. Unmatched driving precision.',
        city: 'Rajkot, Gujarat',
        testDriveCities: ['Rajkot, Gujarat']
      }
    ];

    localStorage.setItem('ld_cars', JSON.stringify(seed));
  },

  getCars()         { return JSON.parse(localStorage.getItem('ld_cars') || '[]'); },
  saveCars(arr)     { localStorage.setItem('ld_cars', JSON.stringify(arr)); },
  addCar(car)       { const a = LD.getCars(); a.unshift(car); LD.saveCars(a); },
  deleteCar(id)     { LD.saveCars(LD.getCars().filter(c => c.id !== id)); },

  /* ── AUTH ── */
  getUsers()        { return JSON.parse(localStorage.getItem('ld_users') || '[]'); },
  saveUsers(arr)    { localStorage.setItem('ld_users', JSON.stringify(arr)); },
  getCurrentUser()  { return JSON.parse(sessionStorage.getItem('ld_user') || 'null'); },
  setCurrentUser(u) { sessionStorage.setItem('ld_user', JSON.stringify(u)); },
  logout()          { sessionStorage.removeItem('ld_user'); },

  register(name, email, phone, password) {
    const users = LD.getUsers();
    if (users.find(u => u.email === email)) return { ok: false, msg: 'Email already registered.' };
    const u = { id: 'u_' + Date.now(), name, email, phone, password, joined: new Date().toLocaleDateString('en-IN') };
    users.push(u);
    LD.saveUsers(users);
    LD.setCurrentUser(u);
    return { ok: true, user: u };
  },
  login(email, password) {
    const users = LD.getUsers();
    const u = users.find(u => u.email === email && u.password === password);
    if (!u) return { ok: false, msg: 'Invalid email or password.' };
    LD.setCurrentUser(u);
    return { ok: true, user: u };
  },

  /* ── WISHLIST ── */
  getWishlist()     { const u = LD.getCurrentUser(); return u ? JSON.parse(localStorage.getItem('ld_wish_' + u.id) || '[]') : []; },
  toggleWish(id)    {
    const u = LD.getCurrentUser(); if (!u) return false;
    let w = LD.getWishlist();
    const idx = w.indexOf(id);
    idx > -1 ? w.splice(idx, 1) : w.push(id);
    localStorage.setItem('ld_wish_' + u.id, JSON.stringify(w));
    return idx === -1; // true = added
  },

  /* ── TEST DRIVES ── */
  getTestDrives()   { return JSON.parse(localStorage.getItem('ld_td') || '[]'); },
  addTestDrive(td)  { 
    const a = LD.getTestDrives(); 
    // Basic duplicate check (same user, same car, same date)
    const exists = a.find(x => x.userId === td.userId && x.carId === td.carId && x.date === td.date);
    if (exists) return false;
    a.push(td); 
    localStorage.setItem('ld_td', JSON.stringify(a)); 
    return true;
  },

  /* ── SELL ENQUIRIES ── */
  getSellEnquiries()   { return JSON.parse(localStorage.getItem('ld_sell') || '[]'); },
  addSellEnquiry(e)    { const a = LD.getSellEnquiries(); a.push(e); localStorage.setItem('ld_sell', JSON.stringify(a)); },

  /* ── CONTACT MSGS ── */
  getContacts()     { return JSON.parse(localStorage.getItem('ld_contacts') || '[]'); },
  addContact(c)     { const a = LD.getContacts(); a.push(c); localStorage.setItem('ld_contacts', JSON.stringify(a)); },
};

/* ── INIT DATA ── */
LD.initCars();

/* ═══════ AUTH GUARD ═══════
   Call this on any page that requires login.
   Pages that DON'T require login: login.html, register.html
   Every other page redirects to login if not authenticated.
*/
function requireAuth() {
  const publicPages = ['index.html', 'buy.html', 'about.html', 'showroom.html', 'contact.html', 'login.html', 'register.html'];
  const currentPage = location.pathname.split('/').pop() || 'index.html';
  if (publicPages.some(p => currentPage.endsWith(p))) return; // allow public pages
  if (!LD.getCurrentUser()) {
    sessionStorage.setItem('ld_redirect', location.href); // remember where they wanted to go
    window.location.replace('login.html');
  }
}
requireAuth(); // runs immediately on every page load

/* ═══════ NAVBAR BUILDER ═══════ */
function buildNav(activePage) {
  const user = LD.getCurrentUser();
  const pages = [
    { href: 'index.html',   label: 'Home' },
    { href: 'buy.html',     label: 'Buy' },
    { href: 'sell.html',    label: 'Sell' },
    { href: 'showroom.html',label: 'Showroom' },
    { href: 'about.html',   label: 'About Us' },
    { href: 'contact.html', label: 'Contact' },
  ];
  let linksHTML = pages.map(p =>
    `<li class="nav-item">
      <a class="nav-link ${p.label === activePage ? 'active-page' : ''}" href="${p.href}">${p.label}</a>
    </li>`
  ).join('');

  let userHTML = user
    ? `<div class="nav-user-info d-none d-lg-flex">
        <div class="nav-avatar">${user.name.charAt(0).toUpperCase()}</div>
        <span style="color:var(--white);font-size:.8rem">Hi, <strong style="color:var(--gold)">${user.name.split(' ')[0]}</strong></span>
       </div>
       <a href="profile.html" class="nav-user-btn nav-link ms-2">My Account</a>
       <a href="#" id="logoutBtn" class="btn-dark-outline ms-2" style="padding:.35rem .9rem;font-size:.72rem">Logout</a>`
    : `<a href="login.html" class="nav-link ms-2" style="color:rgba(255,255,255,.65)">Login</a>
       <a href="register.html" class="nav-user-btn nav-link">Register</a>`;

  document.getElementById('navPlaceholder').innerHTML = `
  <nav class="navbar navbar-expand-lg" id="mainNav">
    <div class="container">
      <a class="navbar-brand" href="index.html">Lux<span>Drive</span><small>Premium Motors</small></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navMenu">
        <ul class="navbar-nav mx-auto gap-1">${linksHTML}</ul>
        <div class="d-flex align-items-center gap-1 mt-2 mt-lg-0">${userHTML}</div>
      </div>
    </div>
  </nav>`;

  document.getElementById('logoutBtn')?.addEventListener('click', e => {
    e.preventDefault(); LD.logout(); window.location.href = 'index.html';
  });

  window.addEventListener('scroll', () => {
    document.getElementById('mainNav')?.classList.toggle('scrolled', window.scrollY > 60);
  });

  /* Ensure modal exists on all pages with nav */
  buildModal();
}

/* ═══════ MODAL BUILDER ═══════ */
function buildModal() {
  if (document.getElementById('carModal')) return;
  const div = document.createElement('div');
  div.innerHTML = `
<div class="modal fade lux-modal" id="carModal" tabindex="-1">
  <div class="modal-dialog modal-xl modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="carModalTitle">Vehicle Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="row g-4">
          <div class="col-md-6">
            <div style="position:relative">
              <img id="carModalMainImg" src="" class="w-100 rounded shadow-sm" style="height:400px;object-fit:cover" alt="Car Image">
              <div id="carModalThumbs" class="modal-thumb-grid mt-3"></div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="car-brand-tag" id="carModalBrand"></div>
            <div style="font-family:'Playfair Display',serif;font-size:1.8rem;font-weight:700;color:var(--white);margin-bottom:.3rem" id="carModalName"></div>
            <div style="font-family:'Playfair Display',serif;font-size:2.2rem;font-weight:700;color:var(--gold);margin-bottom:1.2rem" id="carModalPrice"></div>
            
            <div id="carModalCityInfo"></div>

            <div class="spec-grid mb-4" id="carModalSpecs"></div>
            <p id="carModalDesc" style="color:var(--gray-light);font-size:.88rem;line-height:1.9;margin-bottom:1.5rem"></p>
            
            <div class="d-flex gap-3 flex-wrap mt-auto">
              <a href="tel:+918888888888" class="btn-gold"><i class="fas fa-phone-alt me-2"></i>Call Consultant</a>
              <button class="btn-outline-gold" data-bs-toggle="collapse" data-bs-target="#tdFormPanel"><i class="fas fa-car me-2"></i>Book Test Drive</button>
            </div>

            <div class="collapse mt-4" id="tdFormPanel">
              <div style="background:var(--dark3);border:1px solid rgba(201,168,76,.15);border-radius:4px;padding:1.5rem">
                <div style="font-family:'Barlow Condensed',sans-serif;font-size:.75rem;letter-spacing:3px;text-transform:uppercase;color:var(--gold);margin-bottom:1.2rem;border-bottom:1px solid rgba(201,168,76,.1);padding-bottom:.5rem">Schedule Your Drive</div>
                <input type="hidden" id="tdCarId">
                <input type="hidden" id="tdCarName">
                <div class="row g-2">
                  <div class="col-6"><label class="lux-label">Name</label><input type="text" class="lux-input" id="tdName" placeholder="Full Name"></div>
                  <div class="col-6"><label class="lux-label">Phone</label><input type="tel" class="lux-input" id="tdPhone" placeholder="+91 XXXXX XXXXX"></div>
                  <div class="col-6"><label class="lux-label">Location</label><select class="lux-select" id="tdCity"></select></div>
                  <div class="col-6"><label class="lux-label">Date</label><input type="date" class="lux-input" id="tdDate"></div>
                  <div class="col-6"><label class="lux-label">Time</label><select class="lux-select" id="tdTime"><option>10:00 AM</option><option>11:00 AM</option><option>12:00 PM</option><option>2:00 PM</option><option>3:00 PM</option><option>4:00 PM</option><option>5:00 PM</option></select></div>
                  <div class="col-12 mt-2"><button class="btn-gold w-100" id="tdSubmit" style="justify-content:center">Confirm Booking <i class="fas fa-check ms-1"></i></button></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>`;
  document.body.appendChild(div);
}

/* ═══════ FOOTER BUILDER ═══════ */
function buildFooter() {
  const el = document.getElementById('footerPlaceholder');
  if (!el) return;
  el.innerHTML = `
  <footer>
    <div class="container">
      <div class="row g-5">
        <div class="col-lg-4">
          <div class="footer-logo">Lux<span>Drive</span><small>Premium Motors</small></div>
          <p class="footer-tagline">India's finest luxury pre-owned car marketplace</p>
          <div class="footer-social">
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
            <a href="#"><i class="fab fa-whatsapp"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
          </div>
        </div>
        <div class="col-lg-2 col-6">
          <div class="footer-h">Navigate</div>
          <a class="footer-link" href="index.html">Home</a>
          <a class="footer-link" href="buy.html">Buy a Car</a>
          <a class="footer-link" href="sell.html">Sell Your Car</a>
          <a class="footer-link" href="showroom.html">Showroom</a>
          <a class="footer-link" href="about.html">About Us</a>
        </div>
        <div class="col-lg-2 col-6">
          <div class="footer-h">Explore</div>
          <a class="footer-link" href="buy.html?type=supercar">Supercars</a>
          <a class="footer-link" href="buy.html?type=suv">Luxury SUVs</a>
          <a class="footer-link" href="buy.html?type=sedan">Sedans</a>
          <a class="footer-link" href="contact.html">Finance Enquiry</a>
          <a class="footer-link" href="contact.html">Test Drive</a>
        </div>
        <div class="col-lg-4">
          <div class="footer-h">Visit Us</div>
          <p class="footer-link" style="cursor:default">
            <i class="fas fa-map-marker-alt text-gold me-2"></i>LuxDrive House,  150 Ft Ring Road, Rajkot – 360005  
          </p>
          <p class="footer-link" style="cursor:default">
            <i class="fas fa-phone-alt text-gold me-2"></i>
            <a href="tel:+918888888888" style="color:inherit;text-decoration:none">+91 88888 88888</a>
          </p>
          <p class="footer-link" style="cursor:default">
            <i class="fas fa-envelope text-gold me-2"></i>
            <a href="mailto:hello@luxdrive.in" style="color:inherit;text-decoration:none">hello@luxdrive.in</a>
          </p>
          <p class="footer-link" style="cursor:default">
            <i class="fas fa-clock text-gold me-2"></i>Mon – Sun &nbsp; 9:00 AM – 8:00 PM
          </p>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; 2026 LuxDrive Motors Pvt. Ltd. All rights reserved.</p>
        <p>
          <a href="#" class="footer-link d-inline" style="padding:0;margin-right:1rem">Privacy Policy</a>
          <a href="#" class="footer-link d-inline" style="padding:0">Terms &amp; Conditions</a>
        </p>
      </div>
    </div>
  </footer>
  <!-- CHATBOT -->
  <div id="chatbotWrap">
    <button id="chatToggle" title="Chat with LuxDrive AI">
      <i class="fas fa-comment-dots" id="chatIcon"></i>
      <span class="chat-badge" id="chatBadge" style="display:none">1</span>
    </button>
    <div id="chatWindow">
      <div id="chatHeader">
        <div style="display:flex;align-items:center;gap:.7rem">
          <div style="width:36px;height:36px;border-radius:50%;background:var(--gold);color:var(--black);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.9rem;flex-shrink:0">LD</div>
          <div>
            <div style="font-family:'Playfair Display',serif;font-weight:700;font-size:.9rem;color:var(--white)">LuxDrive Concierge</div>
            <div style="font-size:.68rem;color:#4caf50;letter-spacing:1px">● Online Now</div>
          </div>
        </div>
        <button id="chatClose"><i class="fas fa-times"></i></button>
      </div>
      <div id="chatMessages"></div>
      <div id="chatQuickReplies"></div>
      <div id="chatInputRow">
        <input type="text" id="chatInput" placeholder="Type your message..." autocomplete="off">
        <button id="chatSend"><i class="fas fa-paper-plane"></i></button>
      </div>
    </div>
  </div>`;
  /* ── init chatbot AFTER HTML is in DOM ── */
  initChatbot();
}

/* ═══════ TOAST ═══════ */
function showToast(msg, type = 'gold') {
  let t = document.getElementById('ldToast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'ldToast'; t.className = 'lux-toast';
    document.body.appendChild(t);
  }
  t.style.borderLeftColor = type === 'red' ? 'var(--red)' : type === 'green' ? '#1e7a3e' : 'var(--gold)';
  t.innerHTML = msg;
  t.classList.add('visible');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('visible'), 3200);
}

/* ═══════ SCROLL REVEAL ═══════ */
function initReveal() {
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('show'); });
  }, { threshold: 0.1 });
  document.querySelectorAll('.reveal, .reveal-left, .reveal-right').forEach(el => obs.observe(el));
}
document.addEventListener('DOMContentLoaded', initReveal);

/* ═══════ COUNTER ANIMATE ═══════ */
function animCount(el, target, suffix = '') {
  let n = 0, step = Math.ceil(target / 55);
  const t = setInterval(() => {
    n = Math.min(n + step, target);
    el.textContent = n + suffix;
    if (n >= target) clearInterval(t);
  }, 22);
}

/* ═══════ CAR CARD RENDERER ═══════ */
function carCardHTML(c) {
  const wish = LD.getWishlist();
  const wished = wish.includes(c.id);
  const priceStr = c.price ? `₹${parseFloat(c.price).toFixed(2)} Cr` : 'Price on Request';
  const badgeMap = { featured:'badge-featured', new:'badge-new', sold:'badge-sold' };
  const badgeClass = badgeMap[c.badge] || '';
  const badgeLabel = c.badge ? c.badge.charAt(0).toUpperCase() + c.badge.slice(1) : '';
  const ownerBadge = c.owner !== 'admin' ? '<span class="card-badge badge-user">User Listed</span>' : '';
  const imgs = c.imgs || (c.img ? [c.img] : ['https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80']);
  const uid = 'cc_' + c.id;
  const cityTag = c.city ? `<div class="card-city-tag"><i class="fas fa-map-marker-alt"></i>${c.city}</div>` : '';

  // Build carousel slides
  const slides = imgs.map((src,i) => `
    <div class="car-slide ${i===0?'active':''}">
      <img src="${src}" alt="${c.brand} ${c.model}" loading="lazy"
        onerror="this.src='https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80'">
    </div>`).join('');

  const dots = imgs.length > 1 ? `<div class="slide-dots">
    ${imgs.map((_,i)=>`<span class="slide-dot ${i===0?'active':''}" data-idx="${i}"></span>`).join('')}
  </div>` : '';

  const arrows = imgs.length > 1 ? `
    <button class="slide-arrow slide-prev" data-uid="${uid}"><i class="fas fa-chevron-left"></i></button>
    <button class="slide-arrow slide-next" data-uid="${uid}"><i class="fas fa-chevron-right"></i></button>` : '';

  const photoCount = imgs.length > 1 ? `<div class="photo-count"><i class="fas fa-camera"></i>${imgs.length}</div>` : '';

  return `
  <div class="car-card h-100">
    <div class="car-card-img-wrap" id="${uid}">
      <div class="car-carousel">${slides}</div>
      ${arrows}
      ${dots}
      ${badgeClass ? `<span class="card-badge ${badgeClass}">${badgeLabel}</span>` : ownerBadge}
      ${photoCount}
      <button class="btn-wish ${wished?'on':''}" data-id="${c.id}" title="Wishlist">
        <i class="${wished?'fas':'far'} fa-heart"></i>
      </button>
    </div>
    <div class="car-card-body">
      ${cityTag}
      <div class="car-brand-tag">${c.brand}</div>
      <div class="car-title">${c.model} <span style="color:var(--gray);font-family:'Barlow',sans-serif;font-weight:400;font-size:.8rem">${c.year}</span></div>
      <div class="car-specs-row">
        <span><i class="fas fa-road car-spec"></i>${c.km} km</span>
        <span><i class="fas fa-gas-pump car-spec"></i>${c.fuel}</span>
        <span><i class="fas fa-cog car-spec"></i>${c.trans}</span>
      </div>
      <div class="car-price-bar">
        <span class="car-price">${priceStr}</span>
        <button class="card-action-btn view-car-btn" data-id="${c.id}">Details</button>
      </div>
    </div>
  </div>`;
}

/* ═══════ CAR DETAIL MODAL ═══════ */
function openCarModal(id) {
  const c = LD.getCars().find(x => x.id === id);
  if (!c) return;
  const user = LD.getCurrentUser();
  const priceStr = c.price ? `₹${parseFloat(c.price).toFixed(2)} Crore` : 'Price on Request';
  const imgs = c.imgs || (c.img ? [c.img] : ['https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80']);

  document.getElementById('carModalTitle').textContent = `${c.brand} ${c.model}`;
  document.getElementById('carModalBrand').textContent = c.brand;
  document.getElementById('carModalName').textContent = `${c.model} (${c.year})`;
  document.getElementById('carModalPrice').textContent = priceStr;
  document.getElementById('carModalDesc').textContent = c.desc || '';

  // ── Photo gallery (main + thumbnails)
  document.getElementById('carModalMainImg').src = imgs[0];
  document.getElementById('carModalMainImg').alt = `${c.brand} ${c.model}`;
  const thumbWrap = document.getElementById('carModalThumbs');
  thumbWrap.innerHTML = imgs.map((src,i) => `
    <img src="${src}" data-full="${src}" class="modal-thumb ${i===0?'active':''}"
      alt="Photo ${i+1}" onerror="this.style.display='none'">`).join('');

  // ── Specs
  document.getElementById('carModalSpecs').innerHTML = `
    <div class="spec-item"><div class="spec-lbl">Odometer</div><div class="spec-val">${c.km} km</div></div>
    <div class="spec-item"><div class="spec-lbl">Fuel</div><div class="spec-val">${c.fuel}</div></div>
    <div class="spec-item"><div class="spec-lbl">Transmission</div><div class="spec-val">${c.trans}</div></div>
    <div class="spec-item"><div class="spec-lbl">Power</div><div class="spec-val">${c.power || '—'}</div></div>
    <div class="spec-item"><div class="spec-lbl">Colour</div><div class="spec-val">${c.color || '—'}</div></div>
    <div class="spec-item"><div class="spec-lbl">Type</div><div class="spec-val" style="text-transform:capitalize">${c.type}</div></div>
  `;

  // ── City availability
  const cityHTML = c.city ? `
    <div class="modal-city-row">
      <div class="modal-city-item">
        <div class="modal-city-lbl"><i class="fas fa-map-marker-alt"></i> Car Location</div>
        <div class="modal-city-val">${c.city}</div>
      </div>
      ${c.testDriveCities && c.testDriveCities.length ? `
      <div class="modal-city-item">
        <div class="modal-city-lbl"><i class="fas fa-car"></i> Test Drive Available In</div>
        <div class="modal-city-tags">${c.testDriveCities.map(ct=>`<span class="td-city-tag">${ct}</span>`).join('')}</div>
      </div>` : ''}
    </div>` : '';
  document.getElementById('carModalCityInfo').innerHTML = cityHTML;

  // ── Test drive prefill
  document.getElementById('tdCarName').value = `${c.brand} ${c.model} (${c.year})`;
  document.getElementById('tdCarId').value = c.id;
  // populate test drive city dropdown
  const tdCitySelect = document.getElementById('tdCity');
  if (tdCitySelect) {
    tdCitySelect.innerHTML = '';
    const cities = c.testDriveCities && c.testDriveCities.length ? c.testDriveCities : ['Rajkot, Gujarat','Ahmedabad, Gujarat','Dubai, UAE'];
    cities.forEach(ct => { const o=document.createElement('option'); o.value=ct; o.textContent=ct; tdCitySelect.appendChild(o); });
  }
  if (user) {
    document.getElementById('tdName').value = user.name;
    document.getElementById('tdPhone').value = user.phone || '';
  }
  new bootstrap.Modal('#carModal').show();
}

/* ═══════ GLOBAL DELEGATION ═══════ */
document.addEventListener('click', e => {
  // wishlist
  const wb = e.target.closest('.btn-wish');
  if (wb) {
    const u = LD.getCurrentUser();
    if (!u) { showToast('⚠️ Please login to save to wishlist'); window.location.href='login.html'; return; }
    const id = wb.dataset.id;
    const added = LD.toggleWish(id);
    wb.classList.toggle('on', added);
    wb.innerHTML = `<i class="${added ? 'fas' : 'far'} fa-heart"></i>`;
    showToast(added ? '❤️ Added to wishlist' : 'Removed from wishlist');
  }
  // view car detail
  const vb = e.target.closest('.view-car-btn');
  if (vb) openCarModal(vb.dataset.id);

  // carousel prev/next
  const prevBtn = e.target.closest('.slide-prev');
  const nextBtn = e.target.closest('.slide-next');
  const arrowBtn = prevBtn || nextBtn;
  if (arrowBtn) {
    e.stopPropagation();
    const uid = arrowBtn.dataset.uid;
    const wrap = document.getElementById(uid);
    if (!wrap) return;
    const slides = wrap.querySelectorAll('.car-slide');
    const dots   = wrap.querySelectorAll('.slide-dot');
    let cur = [...slides].findIndex(s => s.classList.contains('active'));
    slides[cur].classList.remove('active');
    dots[cur]?.classList.remove('active');
    if (prevBtn) cur = (cur - 1 + slides.length) % slides.length;
    else         cur = (cur + 1) % slides.length;
    slides[cur].classList.add('active');
    dots[cur]?.classList.add('active');
  }

  // slide dots
  const dot = e.target.closest('.slide-dot');
  if (dot) {
    e.stopPropagation();
    const wrap = dot.closest('.car-card-img-wrap');
    if (!wrap) return;
    const idx = parseInt(dot.dataset.idx);
    wrap.querySelectorAll('.car-slide').forEach((s,i) => s.classList.toggle('active', i===idx));
    wrap.querySelectorAll('.slide-dot').forEach((d,i) => d.classList.toggle('active', i===idx));
  }

  // modal thumbnails
  const thumb = e.target.closest('.modal-thumb');
  if (thumb) {
    document.getElementById('carModalMainImg').src = thumb.dataset.full;
    document.querySelectorAll('.modal-thumb').forEach(t => t.classList.remove('active'));
    thumb.classList.add('active');
  }

  // test drive submit (from global modal)
  if (e.target && e.target.id === 'tdSubmit') {
    const name  = document.getElementById('tdName').value.trim();
    const phone = document.getElementById('tdPhone').value.trim();
    const city  = document.getElementById('tdCity').value;
    const date  = document.getElementById('tdDate').value;
    const time  = document.getElementById('tdTime').value;
    const carId = document.getElementById('tdCarId').value;
    const car   = document.getElementById('tdCarName').value;

    if (!name || !phone || !date) { showToast('⚠️ Please fill all fields', 'red'); return; }
    const u = LD.getCurrentUser();
    if (!u) { showToast('Please login first'); window.location.href = 'login.html'; return; }
    
    LD.addTestDrive({ 
      id: 'td_' + Date.now(), 
      carId, 
      car, 
      userId: u.id, 
      name, 
      phone, 
      city, 
      date, 
      time, 
      created: new Date().toLocaleDateString('en-IN') 
    });
    
    showToast('🚀 Test drive booked! We will call you soon.', 'green');
    bootstrap.Modal.getInstance('#carModal').hide();
    // Reset form
    document.getElementById('tdName').value = '';
    document.getElementById('tdPhone').value = '';
    document.getElementById('tdDate').value = '';
  }
});

/* ═══════════════════════════════════════════════════
   CHATBOT ENGINE — LuxDrive AI Concierge
   ═══════════════════════════════════════════════════ */
function initChatbot() {
  const toggle   = document.getElementById('chatToggle');
  const win      = document.getElementById('chatWindow');
  const closeBtn = document.getElementById('chatClose');
  const msgs     = document.getElementById('chatMessages');
  const input    = document.getElementById('chatInput');
  const sendBtn  = document.getElementById('chatSend');
  const qrArea   = document.getElementById('chatQuickReplies');
  const badge    = document.getElementById('chatBadge');
  if (!toggle) return;

  let isOpen = false;
  let awaitingContext = null;

  /* ── knowledge base ── */
  const user = LD.getCurrentUser();
  const userName = user ? user.name.split(' ')[0] : 'there';

  const KB = [
    { keys:['hello','hi','hey','helo','namaste'],
      reply: `Hey ${userName}! 👋 Welcome to LuxDrive's AI Concierge. I can help you with:\n• Finding the perfect car\n• Test drive bookings\n• Sell / valuation queries\n• Showroom locations\n• Finance & EMI info\n\nWhat can I do for you today?`,
      qr:['Browse Cars','Sell My Car','Showroom Locations','Book Test Drive'] },

    { keys:['buy','browse','find car','looking for','search','inventory','available'],
      reply:'We have a stunning collection of supercars, luxury SUVs, and sedans — all certified.\n\n🔗 Head to our <a href="buy.html" style="color:var(--gold)">Buy page</a> to explore the full inventory with filters.',
      qr:['Supercars','Luxury SUVs','Under ₹3 Cr','Book Test Drive'] },

    { keys:['supercar','lamborghini','ferrari','mclaren','porsche','sports'],
      reply:'Our supercar lineup includes Lamborghini Huracán EVO, Ferrari Roma, Porsche 911 GT3, McLaren 720S and more — all with full service history.\n\n🔗 <a href="buy.html?type=supercar" style="color:var(--gold)">View all Supercars →</a>',
      qr:['Price Range','Book Test Drive','Finance Options'] },

    { keys:['suv','bentayga','g63','cayenne','g wagon','bentley','mercedes'],
      reply:'Our luxury SUVs include Bentley Bentayga S, Mercedes-AMG G63, Porsche Cayenne Turbo GT and more — all in pristine condition.\n\n🔗 <a href="buy.html?type=suv" style="color:var(--gold)">View all SUVs →</a>',
      qr:['Price Range','Book Test Drive','Finance Options'] },

    { keys:['rolls','ghost','phantom','sedan'],
      reply:'Our sedan collection features the Rolls-Royce Ghost EWB, BMW M8 Competition and more bespoke luxury saloons.\n\n🔗 <a href="buy.html?type=sedan" style="color:var(--gold)">View all Sedans →</a>',
      qr:['Book Test Drive','Showroom Visit'] },

    { keys:['sell','valuation','value my car','want to sell','my car'],
      reply:'Great! We offer the best prices for your luxury car. Here\'s how it works:\n\n1️⃣ Submit car details\n2️⃣ Free home inspection\n3️⃣ Instant price offer\n4️⃣ Same-day payment\n\n🔗 <a href="sell.html" style="color:var(--gold)">Get Your Free Valuation →</a>',
      qr:['What cars do you buy?','How long does it take?','Showroom Locations'] },

    { keys:['what car','which car','accept','take car','buy car'],
      reply:'We buy all premium brands including Lamborghini, Ferrari, Porsche, Rolls-Royce, Bentley, McLaren, BMW, Mercedes-Benz, Audi, Bugatti and more.\n\nMinimum value threshold: ₹50 Lakh.',
      qr:['Get Valuation','Contact Us'] },

    { keys:['test drive','drive','try','test'],
      reply:`Love it! 🚗 You can book a test drive directly from any car's detail page.\n\nTest drives available at:\n• Rajkot, Gujarat\n• Ahmedabad, Gujarat\n• Dubai, UAE\n\n🔗 <a href="buy.html" style="color:var(--gold)">Pick a car & book →</a>`,
      qr:['Showroom Locations','Contact Us'] },

    { keys:['showroom','location','visit','where','address','city','rajkot','ahmedabad','dubai'],
      reply:'🏢 We have 3 showroom locations:\n\n📍 <strong style="color:var(--gold)">Rajkot, Gujarat</strong>\n&nbsp;&nbsp;&nbsp;Galaxy Motors Complex, 150 Ft Ring Rd\n\n📍 <strong style="color:var(--gold)">Ahmedabad, Gujarat</strong>\n&nbsp;&nbsp;&nbsp;SG Highway, Prahlad Nagar\n\n🌍 <strong style="color:var(--gold)">Dubai, UAE</strong>\n&nbsp;&nbsp;&nbsp;Sheikh Zayed Rd, Business Bay\n\n🔗 <a href="showroom.html" style="color:var(--gold)">Full Showroom Details →</a>',
      qr:['Book Appointment','Contact Us','Opening Hours'] },

    { keys:['timing','hour','open','close','time','when'],
      reply:'🕘 Our showroom hours:\n\n• Monday – Friday: 9:00 AM – 8:00 PM\n• Saturday: 9:00 AM – 8:00 PM\n• Sunday: 10:00 AM – 6:00 PM\n\nAll locations. Dubai follows GST timezone.',
      qr:['Showroom Locations','Book Appointment'] },

    { keys:['finance','emi','loan','bank','interest','monthly'],
      reply:'💳 LuxDrive Finance Options:\n\n• 15+ banking partners\n• EMI from 0% interest (select schemes)\n• Loan approval in 48 hours\n• Minimal documentation required\n• Amount: ₹50L – ₹10 Crore\n\nSpeak to our finance desk: <a href="tel:+918888888888" style="color:var(--gold)">+91 88888 88888</a>',
      qr:['Contact Finance Desk','Visit Showroom'] },

    { keys:['price','cost','how much','crore','lakh','budget'],
      reply:'Our inventory ranges from ₹80 Lakhs to ₹12+ Crore.\n\n🔍 Use filters on the <a href="buy.html" style="color:var(--gold)">Buy page</a> to sort by budget.\n\nNeed help finding something specific? Tell me your budget!',
      qr:['Under ₹2 Cr','₹2–5 Cr','Above ₹5 Cr'] },

    { keys:['under 2','below 2','less than 2','₹1','₹2','2 crore','budget 2'],
      reply:'Cars under ₹2 Crore include BMW M8 Competition (₹2.1 Cr) and select Porsche models. Check the full range:\n🔗 <a href="buy.html" style="color:var(--gold)">Browse Inventory →</a>',
      qr:['Book Test Drive','Finance Options'] },

    { keys:['above 5','luxury','5 crore','rolls royce','bentley price'],
      reply:'Our ultra-luxury range (₹5 Cr+) includes Rolls-Royce Ghost EWB (₹7.2 Cr) and Bentley Bentayga S (₹5.5 Cr).\n🔗 <a href="buy.html" style="color:var(--gold)">View Premium Collection →</a>',
      qr:['Book Test Drive','Private Viewing'] },

    { keys:['private','vip','exclusive','viewing','appointment'],
      reply:'🥂 We offer private viewing appointments at all showrooms with:\n• Dedicated relationship manager\n• Espresso & hospitality\n• No time pressure\n\n🔗 <a href="showroom.html" style="color:var(--gold)">Book a Private Appointment →</a>',
      qr:['Showroom Locations','Contact Us'] },

    { keys:['delivery','ship','transport','send'],
      reply:'🚛 Pan-India delivery available!\n\n• Enclosed car carriers\n• Full insurance in transit\n• GPS tracked delivery\n• 3–7 days to major cities\n• White-glove handover\n\nDelivery charges vary by distance.',
      qr:['Contact Us','More Info'] },

    { keys:['paper','rc','insurance','noc','transfer','document'],
      reply:'📄 We handle ALL paperwork:\n✅ RC Transfer\n✅ Insurance Transfer\n✅ NOC from finance\n✅ Form 28, 29, 30\n\nTypically completed within 7 working days after sale.',
      qr:['Contact Us','Visit Showroom'] },

    { keys:['contact','phone','call','email','whatsapp','number'],
      reply:'📞 Reach us anytime:\n\n<strong style="color:var(--gold)">Call:</strong> <a href="tel:+918888888888" style="color:var(--gold)">+91 88888 88888</a>\n<strong style="color:var(--gold)">Email:</strong> hello@luxdrive.in\n<strong style="color:var(--gold)">WhatsApp:</strong> +91 88888 88888\n\n🔗 <a href="contact.html" style="color:var(--gold)">Contact Page →</a>',
      qr:['Showroom Locations','Book Appointment'] },

    { keys:['thank','thanks','ok','okay','great','awesome','perfect'],
      reply:`You\'re most welcome, ${userName}! 😊 Is there anything else I can help you with today?`,
      qr:['Browse Cars','Showroom Locations','Contact Us'] },

    { keys:['bye','goodbye','no thanks','nothing','done'],
      reply:`Goodbye, ${userName}! 🙏 It was a pleasure. Feel free to chat again anytime. Happy driving! 🏎️`,
      qr:[] },
  ];

  const DEFAULT_REPLY = `I'm not sure about that, but I'd love to help! Try one of these topics or call us at <a href="tel:+918888888888" style="color:var(--gold)">+91 88888 88888</a>.`;
  const DEFAULT_QR = ['Browse Cars','Showroom Locations','Finance Options','Contact Us'];

  /* ── toggle open/close ── */
  function openChat() {
    isOpen = true;
    win.classList.add('open');
    badge.style.display = 'none';
    if (msgs.children.length === 0) {
      setTimeout(() => botReply(`Hey ${userName}! 👋 I'm LuxDrive's AI Concierge. How can I help you today?`, ['Browse Cars','Sell My Car','Showroom Locations','Book Test Drive']), 300);
    }
    setTimeout(() => input.focus(), 350);
  }
  function closeChat() {
    isOpen = false;
    win.classList.remove('open');
  }

  toggle.addEventListener('click', () => isOpen ? closeChat() : openChat());
  closeBtn.addEventListener('click', closeChat);

  /* ── messaging ── */
  function addMsg(text, who) {
    const div = document.createElement('div');
    div.className = `chat-msg ${who}`;
    div.innerHTML = text;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function showTyping() {
    const t = document.createElement('div');
    t.className = 'chat-typing'; t.id = 'chatTyping';
    t.innerHTML = '<span></span><span></span><span></span>';
    msgs.appendChild(t);
    msgs.scrollTop = msgs.scrollHeight;
  }
  function hideTyping() {
    document.getElementById('chatTyping')?.remove();
  }

  function setQR(qrs) {
    qrArea.innerHTML = '';
    (qrs || []).forEach(q => {
      const b = document.createElement('button');
      b.className = 'qr-btn'; b.textContent = q;
      b.addEventListener('click', () => handleSend(q));
      qrArea.appendChild(b);
    });
  }

  function botReply(text, qrs, delay = 900) {
    showTyping();
    setTimeout(() => {
      hideTyping();
      addMsg(text, 'bot');
      setQR(qrs);
    }, delay);
  }

  function handleSend(text) {
    const q = (text || input.value).trim();
    if (!q) return;
    addMsg(q, 'user');
    input.value = '';
    setQR([]);

    const lower = q.toLowerCase();
    const match = KB.find(k => k.keys.some(kw => lower.includes(kw)));
    if (match) {
      botReply(match.reply, match.qr);
    } else {
      botReply(DEFAULT_REPLY, DEFAULT_QR);
    }
  }

  sendBtn.addEventListener('click', () => handleSend());
  input.addEventListener('keydown', e => { if (e.key === 'Enter') handleSend(); });

  /* ── show badge after 3s ── */
  setTimeout(() => { badge.style.display = 'flex'; }, 3000);
}

/* ═══════════════════════════════════════════════════
   INDEX PAGE — Inline Script
   ═══════════════════════════════════════════════════ */
function initIndexPage() {
  // Only run on index.html
  if (!document.getElementById('hero')) return;

  buildNav('Home');
  buildFooter();

  // Welcome banner
  const u = LD.getCurrentUser();
  if (u) { $('#welcomeBanner').show(); $('#welcomeName').text(u.name); }

  // Ticker
  const items = ['Lamborghini Huracán EVO','Ferrari Roma','Porsche 911 GT3','Rolls-Royce Ghost','McLaren 720S','Bentley Bentayga','Mercedes G63','BMW M8 Competition'];
  let t = ''; for (let i = 0; i < 2; i++) items.forEach(x => t += `<span class="ticker-item">${x}</span><span class="ticker-dot">◆</span>`);
  $('#ticker').html(t);

  // Featured cars (badge=featured or first 6)
  const cars = LD.getCars();
  const featured = cars.filter(c => c.badge === 'featured').slice(0, 3).concat(cars.filter(c => c.badge !== 'featured').slice(0, 3));
  featured.slice(0, 6).forEach(c => {
    $('#featuredGrid').append(`<div class="col-md-6 col-lg-4 reveal">${carCardHTML(c)}</div>`);
  });

  // Testimonials
  const tData = [
    { n:'Maharshi', c:'Lamborghini Huracán', t:'Bought my dream Huracán from LuxDrive. The experience was seamless — team handled everything from inspection to registration. Could not be happier!' },
    { n:'Kunj',     c:'Rolls-Royce Ghost',   t:'Sold my Ghost at a price far better than other dealers quoted. Transparent valuation and payment in account by evening. Exceptional.' },
    { n:'Kartik',   c:'Porsche 911 GT3',     t:'From first inquiry to delivery in Bangalore — perfect condition. The team kept me updated at every single step. 10/10.' },
    { n:'Kunal',    c:'BMW M8 Competition',  t:'Finance sorted in 48 hours. Buying a luxury car felt genuinely easy. The concierge service post-delivery is a brilliant touch.' },
    { n:'Virat',    c:'McLaren 720S',         t:"Third car from LuxDrive. Every time the quality and buying experience improves. Truly India's best luxury car marketplace." },
    { n:'Rohit',    c:'Bentley Bentayga',    t:'The bespoke sourcing found me exactly the Bentayga spec I wanted. That level of dedication to customers is extremely rare.' },
  ];
  tData.forEach(d => {
    $('#testiGrid').append(`<div class="col-md-6 col-lg-4 reveal"><div class="testi-card">
      <div class="testi-stars">★★★★★</div>
      <p class="testi-text">"${d.t}"</p>
      <div class="testi-author">
        <div class="testi-av">${d.n.charAt(0)}</div>
        <div><div class="testi-name">${d.n}</div><div class="testi-car">${d.c}</div></div>
      </div>
    </div></div>`);
  });

  // Counter
  let counted = false;
  $(window).on('scroll', function () {
    if (!counted && $(this).scrollTop() > 200) {
      counted = true;
      animCount(document.getElementById('cntSold'),    1500, '+');
      animCount(document.getElementById('cntClients'), 1200, '+');
      animCount(document.getElementById('cntYrs'),     14,   '');
      animCount(document.getElementById('cntsh'),      3,    '');
      animCount(document.getElementById('rpt'),        20,   '%');
      animCount(document.getElementById('gl'),         2,    '');
    }
  });

  initReveal();
}

$(function () { initIndexPage(); });

/* ═══════════════════════════════════════════════════
   ABOUT PAGE — Inline Script
   ═══════════════════════════════════════════════════ */
function initAboutPage() {
  // Only run on about.html
  if (!document.querySelector('.timeline')) return;

  buildNav('About Us');
  buildFooter();

  let counted = false;
  $(window).on('scroll', function () {
    if (!counted && $(this).scrollTop() > 200) {
      counted = true;
      animCount(document.getElementById('cntSold'),    1500, '+');
      animCount(document.getElementById('cntClients'), 1200, '+');
      animCount(document.getElementById('cntYrs'),     14,   '');
      animCount(document.getElementById('cntsh'),      3,    '');
      animCount(document.getElementById('rpt'),        20,   '%');
      animCount(document.getElementById('gl'),         2,    '');
    }
  });

  initReveal();
}

$(function () { initAboutPage(); });

/* ═══════════════════════════════════════════════════
   BUY PAGE — Inline Script
   ═══════════════════════════════════════════════════ */
function initBuyPage() {
  if (!document.getElementById('carGrid')) return;

  buildNav('Buy');
  buildFooter();

  let allCars = LD.getCars();

  function renderGrid(cars) {
    $('#carGrid').empty();
    if (!cars.length) { $('#noResults').show(); $('#resultCount').text(0); return; }
    $('#noResults').hide(); $('#resultCount').text(cars.length);
    cars.forEach(c => $('#carGrid').append(`<div class="col-md-6 col-xl-4 reveal">${carCardHTML(c)}</div>`));
    initReveal();
  }

  function applyAll() {
    let cars = [...allCars];
    const q = $('#searchInput').val().toLowerCase().trim();
    const types  = [...$('.type-filter:checked')].map(x => x.value);
    const brands = [...$('.brand-filter:checked')].map(x => x.value);
    const fuels  = [...$('.fuel-filter:checked')].map(x => x.value);
    const maxPrice = parseFloat($('#budgetRange').val());
    if (q)      cars = cars.filter(c => (c.brand + ' ' + c.model + ' ' + c.color + ' ' + c.year).toLowerCase().includes(q));
    if (types.length)  cars = cars.filter(c => types.includes(c.type));
    if (brands.length) cars = cars.filter(c => brands.includes(c.brand.toLowerCase()));
    if (fuels.length)  cars = cars.filter(c => fuels.includes(c.fuel.toLowerCase()));
    cars = cars.filter(c => parseFloat(c.price) <= maxPrice);
    const sort = $('.sort-btn.active').data('sort');
    if (sort === 'price-asc')  cars.sort((a, b) => a.price - b.price);
    else if (sort === 'price-desc') cars.sort((a, b) => b.price - a.price);
    else if (sort === 'year')  cars.sort((a, b) => a.year - b.year);
    renderGrid(cars);
  }

  renderGrid(allCars);

  $('#budgetRange').on('input', function () { $('#budgetVal').text('₹' + $(this).val() + ' Cr'); });
  $('#applyFilters').on('click', applyAll);
  $('#searchInput').on('input', applyAll);
  $('#clearFilters').on('click', function () {
    $('input[type=checkbox]').prop('checked', false);
    $('#budgetRange').val(10); $('#budgetVal').text('₹10 Cr');
    $('#searchInput').val(''); applyAll();
  });
  $(document).on('click', '.sort-btn', function () {
    $('.sort-btn').removeClass('active'); $(this).addClass('active'); applyAll();
  });

  // URL params
  const p = new URLSearchParams(location.search);
  if (p.get('type')) { $(`.type-filter[value="${p.get('type')}"]`).prop('checked', true); applyAll(); }

  // Test drive
  $('#tdSubmit').on('click', function () {
    const n = $('#tdName').val().trim(), ph = $('#tdPhone').val().trim(), d = $('#tdDate').val();
    if (!n || !ph || !d) { showToast('⚠️ Please fill all fields', 'red'); return; }
    const u = LD.getCurrentUser();
    if (!u) { showToast('Please login first'); window.location.href = 'login.html'; return; }
    LD.addTestDrive({ id: 'td_' + Date.now(), carId: $('#tdCarId').val(), car: $('#tdCarName').val(), userId: u.id, name: n, phone: ph, city: $('#tdCity').val(), date: d, time: $('#tdTime').val(), created: new Date().toLocaleDateString() });
    showToast("✅ Test Drive booked in " + $('#tdCity').val() + "! We'll call you to confirm.", 'green');
    bootstrap.Modal.getInstance('#carModal').hide();
  });
}

$(function () { initBuyPage(); });

/* ═══════════════════════════════════════════════════
   CONTACT PAGE — Inline Script
   ═══════════════════════════════════════════════════ */
function initContactPage() {
  if (!document.getElementById('contactBtn')) return;
  buildNav('Contact'); buildFooter();
  const u = LD.getCurrentUser();
  if (u) { $('#c_name').val(u.name); $('#c_phone').val(u.phone || ''); $('#c_email').val(u.email || ''); }

  $('#contactBtn').on('click', function () {
    const n = $('#c_name').val().trim(), ph = $('#c_phone').val().trim(), msg = $('#c_message').val().trim();
    if (!n || !ph || !msg) { showToast('⚠️ Please fill Name, Phone and Message', 'red'); return; }
    LD.addContact({ id: 'ct_' + Date.now(), type: 'contact', name: n, phone: ph, email: $('#c_email').val(), subject: $('#c_subject').val(), message: msg, created: new Date().toLocaleDateString() });
    showToast("✅ Message sent! We'll get back within 2 hours.", 'green');
    $('#c_message').val('');
  });

  $(document).on('click', '.faq-q', function () {
    const ans = $(this).next('.faq-a');
    const isOpen = $(this).hasClass('open');
    $('.faq-q').removeClass('open').next('.faq-a').slideUp(200);
    if (!isOpen) { $(this).addClass('open'); ans.slideDown(200); }
  });

  initReveal();
}
$(function () { initContactPage(); });

/* ═══════════════════════════════════════════════════
   LOGIN PAGE — Inline Script
   ═══════════════════════════════════════════════════ */
function initLoginPage() {
  if (!document.getElementById('loginPanel')) return;
  if (LD.getCurrentUser()) window.location.href = 'index.html';

  $('.auth-tab').on('click', function () {
    const tab = $(this).data('tab');
    $('.auth-tab').removeClass('active'); $(this).addClass('active');
    $('.auth-panel').removeClass('active'); $('#' + tab + 'Panel').addClass('active');
  });
  $('.switch-tab').on('click', function (e) {
    e.preventDefault();
    $('.auth-tab[data-tab="' + $(this).data('to') + '"]').trigger('click');
  });

  const params = new URLSearchParams(location.search);
  if (params.get('tab') === 'register') $('.auth-tab[data-tab="register"]').trigger('click');

  $('#toggleLoginPass').on('click', function () {
    const inp = $('#loginPass'); inp.attr('type', inp.attr('type') === 'password' ? 'text' : 'password');
    $(this).find('i').toggleClass('fa-eye fa-eye-slash');
  });
  $('#toggleRegPass').on('click', function () {
    const inp = $('#regPass'); inp.attr('type', inp.attr('type') === 'password' ? 'text' : 'password');
    $(this).find('i').toggleClass('fa-eye fa-eye-slash');
  });

  $('#loginBtn').on('click', function () {
    const email = $('#loginEmail').val().trim(), pass = $('#loginPass').val();
    const res = LD.login(email, pass);
    if (!res.ok) { $('#loginErr').text(res.msg).show(); return; }
    showToast(`👋 Welcome back, ${res.user.name.split(' ')[0]}!`, 'green');
    const redir = sessionStorage.getItem('ld_redirect') || 'index.html';
    sessionStorage.removeItem('ld_redirect');
    setTimeout(() => window.location.href = redir, 800);
  });
  $('#loginEmail, #loginPass').on('keypress', function (e) { if (e.which === 13) $('#loginBtn').trigger('click'); });

  $('#regBtn').on('click', function () {
    const name = $('#regName').val().trim(), email = $('#regEmail').val().trim();
    const phone = $('#regPhone').val().trim(), pass = $('#regPass').val();
    const pass2 = $('#regPass2').val(), agree = $('#regAgree').is(':checked');
    if (!name || !email || !phone || !pass) { $('#regErr').text('Please fill all fields.').show(); return; }
    if (pass.length < 6) { $('#regErr').text('Password must be at least 6 characters.').show(); return; }
    if (pass !== pass2) { $('#regErr').text('Passwords do not match.').show(); return; }
    if (!agree) { $('#regErr').text('Please accept the Terms of Service.').show(); return; }
    const res = LD.register(name, email, phone, pass);
    if (!res.ok) { $('#regErr').text(res.msg).show(); return; }
    showToast(`🎉 Welcome to LuxDrive, ${name.split(' ')[0]}!`, 'green');
    setTimeout(() => window.location.href = 'index.html', 900);
  });
}
$(function () { initLoginPage(); });

/* ═══════════════════════════════════════════════════
   SELL PAGE — Inline Script
   ═══════════════════════════════════════════════════ */
function initSellPage() {
  if (!document.getElementById('sellEnquiryBtn')) return;
  buildNav('Sell'); buildFooter();
  const user = LD.getCurrentUser();

  $('.sell-tab').on('click', function () {
    const p = $(this).data('panel');
    $('.sell-tab').removeClass('active'); $(this).addClass('active');
    $('.sell-panel').removeClass('active'); $('#panel-' + p).addClass('active');
    if (p === 'listing') {
      if (!user) { $('#loginPrompt').show(); $('#listingForm').hide(); }
      else { $('#loginPrompt').hide(); $('#listingForm').show(); $('#lst_seller').val(user.name); $('#lst_phone').val(user.phone || ''); }
    }
  });

  $('#switchEnquiry').on('click', function (e) { e.preventDefault(); $('.sell-tab[data-panel="enquiry"]').trigger('click'); });

  $('#sellEnquiryBtn').on('click', function () {
    const n = $('#sq_name').val().trim(), ph = $('#sq_phone').val().trim(), br = $('#sq_brand').val(), mo = $('#sq_model').val().trim();
    if (!n || !ph || !br || !mo) { showToast('⚠️ Please fill all required fields', 'red'); return; }
    LD.addSellEnquiry({ id: 'se_' + Date.now(), name: n, phone: ph, email: $('#sq_email').val(), city: $('#sq_city').val(), brand: br, model: mo, year: $('#sq_year').val(), km: $('#sq_km').val(), notes: $('#sq_notes').val(), created: new Date().toLocaleDateString() });
    showToast("✅ Valuation request submitted! We'll call within 2 hours.", 'green');
    $('#panel-enquiry input,#panel-enquiry select,#panel-enquiry textarea').val('');
  });

  let currentPhotoMode = 'url';
  window.setPhotoMode = function (mode) {
    currentPhotoMode = mode;
    if (mode === 'url') {
      document.getElementById('urlMode').style.display = 'block';
      document.getElementById('fileMode').style.display = 'none';
      document.getElementById('modeUrlBtn').classList.add('active');
      document.getElementById('modeFileBtn').classList.remove('active');
    } else {
      document.getElementById('urlMode').style.display = 'none';
      document.getElementById('fileMode').style.display = 'block';
      document.getElementById('modeUrlBtn').classList.remove('active');
      document.getElementById('modeFileBtn').classList.add('active');
    }
  };

  window.previewUrl = function (input, idx) {
    const thumb = document.getElementById('thumb' + idx);
    const url = input.value.trim();
    if (url) { thumb.innerHTML = `<img src="${url}" onerror="this.parentElement.innerHTML='<span style=color:red;font-size:.6rem>Bad URL</span>'">`; }
    else { thumb.innerHTML = ''; thumb.className = 'url-thumb url-thumb-empty'; }
  };
  document.querySelectorAll('.url-thumb').forEach(t => t.classList.add('url-thumb-empty'));

  const MAX_PHOTOS = 4;
  let uploadedPhotos = [];
  function renderPhotoGrid() {
    const grid = document.getElementById('photoPreviewGrid');
    if (!grid) return;
    grid.innerHTML = '';
    uploadedPhotos.forEach((src, i) => {
      const item = document.createElement('div');
      item.className = 'photo-preview-item';
      item.innerHTML = `<img src="${src}" alt="Photo ${i+1}"><button class="photo-remove-btn" data-idx="${i}" title="Remove"><i class="fas fa-times"></i></button>`;
      grid.appendChild(item);
    });
    if (uploadedPhotos.length < MAX_PHOTOS) {
      const slot = document.createElement('div');
      slot.className = 'photo-add-slot'; slot.id = 'photoAddSlot';
      slot.innerHTML = `<i class="fas fa-plus"></i><span>ADD PHOTO</span>`;
      slot.addEventListener('click', () => document.getElementById('photoFileInput').click());
      grid.appendChild(slot);
    }
    const drop = document.getElementById('photoDropArea');
    let badge = document.getElementById('photoCountBadge');
    if (!badge) { badge = document.createElement('div'); badge.id = 'photoCountBadge'; badge.className = 'photo-count-badge'; drop.after(badge); }
    badge.textContent = uploadedPhotos.length > 0 ? `${uploadedPhotos.length} / ${MAX_PHOTOS} photos added` : '';
  }
  function readFilesAsBase64(files) {
    [...files].slice(0, MAX_PHOTOS - uploadedPhotos.length).forEach(file => {
      if (!file.type.startsWith('image/')) return;
      if (file.size > 5 * 1024 * 1024) { showToast(`⚠️ ${file.name} is over 5MB — skipped`, 'red'); return; }
      const reader = new FileReader();
      reader.onload = e => { uploadedPhotos.push(e.target.result); renderPhotoGrid(); };
      reader.readAsDataURL(file);
    });
  }
  $('#photoBrowseBtn').on('click', function (e) { e.stopPropagation(); document.getElementById('photoFileInput').click(); });
  document.getElementById('photoFileInput').addEventListener('change', function () { readFilesAsBase64(this.files); this.value = ''; });
  document.getElementById('photoDropArea').addEventListener('click', function (e) { if (e.target.closest('#photoBrowseBtn')) return; document.getElementById('photoFileInput').click(); });
  const dropArea = document.getElementById('photoDropArea');
  ['dragenter','dragover'].forEach(ev => dropArea.addEventListener(ev, e => { e.preventDefault(); dropArea.classList.add('drag-over'); }));
  ['dragleave','drop'].forEach(ev => dropArea.addEventListener(ev, e => { e.preventDefault(); dropArea.classList.remove('drag-over'); }));
  dropArea.addEventListener('drop', e => { readFilesAsBase64(e.dataTransfer.files); });
  document.getElementById('photoPreviewGrid').addEventListener('click', function (e) {
    const btn = e.target.closest('.photo-remove-btn');
    if (btn) { uploadedPhotos.splice(parseInt(btn.dataset.idx), 1); renderPhotoGrid(); }
  });
  renderPhotoGrid();

  $('#listCarBtn').on('click', function () {
    const brand = $('#lst_brand').val(), model = $('#lst_model').val().trim();
    const price = $('#lst_price').val(), km = $('#lst_km').val().trim();
    if (!brand || !model || !price || !km) { showToast('⚠️ Please fill Brand, Model, Price and KM', 'red'); return; }
    let finalImgs = [];
    if (currentPhotoMode === 'url') {
      finalImgs = [...document.querySelectorAll('.url-img-input')].map(i => i.value.trim()).filter(Boolean);
      if (finalImgs.length === 0) { showToast('⚠️ Please enter at least 1 photo URL', 'red'); return; }
    } else {
      finalImgs = uploadedPhotos;
      if (finalImgs.length === 0) { showToast('⚠️ Please add at least 1 photo', 'red'); return; }
    }
    const car = { id: 'c_' + Date.now(), brand, model, year: parseInt($('#lst_year').val()), km, fuel: $('#lst_fuel').val(), trans: $('#lst_trans').val(), power: $('#lst_power').val(), color: $('#lst_color').val(), price: parseFloat(price), type: $('#lst_type').val(), badge: '', owner: user.id, imgs: finalImgs, desc: $('#lst_desc').val(), city: $('#lst_city').val(), testDriveCities: [...$('.td-city-check:checked')].map(x => x.value), sellerName: $('#lst_seller').val(), sellerPhone: $('#lst_phone').val(), listed: new Date().toLocaleDateString() };
    LD.addCar(car);
    showToast('🚀 Your car is now live on LuxDrive!', 'green');
    setTimeout(() => window.location.href = 'buy.html', 1500);
  });
  initReveal();
}
$(function () { initSellPage(); });

/* ═══════════════════════════════════════════════════
   SHOWROOM PAGE — Inline Script
   ═══════════════════════════════════════════════════ */
function initShowroomPage() {
  if (!document.getElementById('apptBtn')) return;
  buildNav('Showroom'); buildFooter();
  const u = LD.getCurrentUser();
  if (u) { $('#appt_name').val(u.name); $('#appt_phone').val(u.phone || ''); }

  $('.city-tab').on('click', function () {
    $('.city-tab').removeClass('active'); $(this).addClass('active');
    $('.city-panel').removeClass('active'); $('#city-' + $(this).data('city')).addClass('active');
    initReveal();
  });

  $('#apptBtn').on('click', function () {
    const n = $('#appt_name').val().trim(), ph = $('#appt_phone').val().trim(), d = $('#appt_date').val();
    if (!n || !ph || !d) { showToast('⚠️ Please fill Name, Phone and Date', 'red'); return; }
    LD.addContact({ id: 'ap_' + Date.now(), type: 'appointment', name: n, phone: ph, email: $('#appt_email').val(), date: d, time: $('#appt_time').val(), interest: $('#appt_interest').val(), notes: $('#appt_notes').val(), created: new Date().toLocaleDateString() });
    showToast('✅ Appointment booked! See you soon at LuxDrive.', 'green');
    $('#appt_date').val(''); $('#appt_notes').val('');
  });
  initReveal();
}
$(function () { initShowroomPage(); });

/* ═══════════════════════════════════════════════════
   PROFILE PAGE — Inline Script
   ═══════════════════════════════════════════════════ */
function initProfilePage() {
  if (!document.getElementById('profileAv')) return;
  buildNav(''); buildFooter();
  const u = LD.getCurrentUser();
  if (!u) { window.location.href = 'login.html'; return; }

  $('#profileAv').text(u.name.charAt(0).toUpperCase());
  $('#profileName').text(u.name);
  $('#profileSince').text('Member since ' + u.joined);
  $('#welcomeMsg').text('Welcome back, ' + u.name.split(' ')[0] + '!');
  $('#acc_name').val(u.name); $('#acc_phone').val(u.phone || ''); $('#acc_email').val(u.email); $('#acc_since').val(u.joined);

  const wish = LD.getWishlist();
  
  // Cleanup duplicates from localStorage (one-time merge)
  const allTds = LD.getTestDrives();
  const uniqueTds = [];
  allTds.forEach(t => { if (!uniqueTds.find(x => x.userId === t.userId && x.carId === t.carId && x.date === t.date)) uniqueTds.push(t); });
  if (uniqueTds.length < allTds.length) localStorage.setItem('ld_td', JSON.stringify(uniqueTds));

  const tds = LD.getTestDrives().filter(t => t.userId === u.id);
  const myListings = LD.getCars().filter(c => c.owner === u.id);
  const joinDate = new Date(u.joined.split('/').reverse().join('-'));
  const days = Math.max(1, Math.floor((Date.now() - joinDate) / (1000 * 60 * 60 * 24)));
  $('#ov_wish').text(wish.length); $('#ov_td').text(tds.length); $('#ov_list').text(myListings.length); $('#ov_days').text(days);

  $('.side-nav-item[data-panel]').on('click', function () {
    $('.side-nav-item').removeClass('active'); $(this).addClass('active');
    const p = $(this).data('panel');
    $('.dash-panel').removeClass('active'); $('#panel-' + p).addClass('active');
    if (p === 'wishlist') loadWishlist();
    if (p === 'testdrives') loadTDs();
    if (p === 'mylistings') loadMyListings();
  });
  $('#sideLogout').on('click', function () { LD.logout(); window.location.href = 'index.html'; });

  function loadWishlist() {
    $('#wishGrid').empty();
    const ids = LD.getWishlist(); const cars = LD.getCars().filter(c => ids.includes(c.id));
    if (!cars.length) { $('#wishEmpty').show(); return; } $('#wishEmpty').hide();
    cars.forEach(c => $('#wishGrid').append(`<div class="col-md-6 col-lg-4">${carCardHTML(c)}</div>`));
  }
  function loadTDs() {
    $('#tdList').empty();
    const tds = LD.getTestDrives().filter(t => t.userId === u.id);
    if (!tds.length) { $('#tdEmpty').show(); return; } $('#tdEmpty').hide();
    tds.forEach(t => {
      $('#tdList').append(`<div class="td-card mb-3">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
          <div>
            <div class="td-car">${t.car}</div>
            <div class="td-meta">Date: <span>${t.date}</span> &nbsp;|&nbsp; Time: <span>${t.time}</span></div>
            <div class="td-meta mt-1">Booked on: ${t.created}</div>
          </div>
          <span class="tag-green">Confirmed</span>
        </div>
      </div>`);
    });
  }
  function loadMyListings() {
    $('#myListGrid').empty();
    const cars = LD.getCars().filter(c => c.owner === u.id);
    if (!cars.length) { $('#listEmpty').show(); return; } $('#listEmpty').hide();
    cars.forEach(c => {
      const priceStr = c.price ? `₹${parseFloat(c.price).toFixed(2)} Cr` : 'Price on Request';
      $('#myListGrid').append(`<div class="col-md-6">
        <div class="car-card">
          <div class="car-card-img-wrap">
            <img class="car-card-img" src="${(c.imgs && c.imgs[0]) || c.img || 'default-car.jpg'}" onerror="this.onerror=null;this.src='default-car.jpg';" alt="${c.brand} ${c.model}">
            <span class="card-badge badge-user">Your Listing</span>
          </div>
          <div class="car-card-body">
            <div class="car-brand-tag">${c.brand}</div>
            <div class="car-title">${c.model} (${c.year})</div>
            <div class="car-price-bar"><span class="car-price">${priceStr}</span><span class="tag-green">Live</span></div>
            <div class="listing-actions"><button class="card-action-btn delete-listing" data-id="${c.id}" style="color:var(--red);border-color:rgba(184,50,50,.3)">Delete</button></div>
          </div>
        </div>
      </div>`);
    });
  }

  $(document).on('click', '.delete-listing', function () {
    if (!confirm('Remove this listing?')) return;
    LD.deleteCar($(this).data('id')); showToast('Listing removed', 'red');
    loadMyListings(); $('#ov_list').text(LD.getCars().filter(c => c.owner === u.id).length);
  });

  $('#saveAccBtn').on('click', function () {
    const users = LD.getUsers(); const idx = users.findIndex(x => x.id === u.id);
    if (idx > -1) { users[idx].name = $('#acc_name').val().trim(); users[idx].phone = $('#acc_phone').val().trim(); }
    LD.saveUsers(users);
    const updated = { ...u, name: $('#acc_name').val().trim(), phone: $('#acc_phone').val().trim() };
    LD.setCurrentUser(updated); showToast('✅ Profile updated!', 'green'); $('#profileName').text(updated.name);
  });

  $('#changePassBtn').on('click', function () {
    const cur = $('#acc_curpass').val(), np = $('#acc_newpass').val(), cp = $('#acc_confpass').val();
    if (cur !== u.password) { showToast('⚠️ Current password is incorrect', 'red'); return; }
    if (np.length < 6) { showToast('⚠️ New password must be 6+ characters', 'red'); return; }
    if (np !== cp) { showToast('⚠️ Passwords do not match', 'red'); return; }
    const users = LD.getUsers(); const idx = users.findIndex(x => x.id === u.id);
    if (idx > -1) { users[idx].password = np; LD.saveUsers(users); LD.setCurrentUser({ ...u, password: np }); }
    showToast('✅ Password changed!', 'green'); $('#acc_curpass,#acc_newpass,#acc_confpass').val('');
  });
}
$(function () { initProfilePage(); });
