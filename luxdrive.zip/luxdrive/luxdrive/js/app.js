/* ═══════════════════════════════════════════════════
   LUXDRIVE MOTORS — SHARED JAVASCRIPT
   ═══════════════════════════════════════════════════ */

/* ── DATA STORE (simulates backend with localStorage) ── */
const LD = {
  /* seed default cars — v6 = 3 starter cars with easy image URLs */
  initCars() {
    if (localStorage.getItem('ld_seed_ver') === 'v6') return;
    localStorage.removeItem('ld_cars');
    localStorage.setItem('ld_seed_ver', 'v6');

    // ═══════════════════════════════════════════════════════
    //  CHANGE IMAGES HERE — just replace the URLs below
    //  Each car has 4 image slots (img1 = main/cover photo)
    // ═══════════════════════════════════════════════════════

    // ── CAR 1: Lamborghini Urus ──

    localStorage.setItem('ld_cars', JSON.stringify(seed));
  },

  getCars()         { return JSON.parse(localStorage.getItem('ld_cars') || '[]'); },
  saveCars(arr)     { localStorage.setItem('ld_cars', JSON.stringify(arr)); },
  addCar(car)       { const a = LD.getCars(); a.unshift(car); LD.saveCars(a); },
  deleteCar(id)     { LD.saveCars(LD.getCars().filter(c => c.id !== id)); },

  /* ── AUTH ── */
  getUsers()        { return JSON.parse(localStorage.getItem('ld_users') || '[]'); },
  saveUsers(arr)    { localStorage.setItem('ld_users', JSON.stringify(arr)); },
  getCurrentUser()  { return JSON.parse(sessionStorage.getItem('ld_user') || 'null'); },
  setCurrentUser(u) { sessionStorage.setItem('ld_user', JSON.stringify(u)); },
  logout()          { sessionStorage.removeItem('ld_user'); },

  register(name, email, phone, password) {
    const users = LD.getUsers();
    if (users.find(u => u.email === email)) return { ok: false, msg: 'Email already registered.' };
    const u = { id: 'u_' + Date.now(), name, email, phone, password, joined: new Date().toLocaleDateString('en-IN') };
    users.push(u);
    LD.saveUsers(users);
    LD.setCurrentUser(u);
    return { ok: true, user: u };
  },
  login(email, password) {
    const users = LD.getUsers();
    const u = users.find(u => u.email === email && u.password === password);
    if (!u) return { ok: false, msg: 'Invalid email or password.' };
    LD.setCurrentUser(u);
    return { ok: true, user: u };
  },

  /* ── WISHLIST ── */
  getWishlist()     { const u = LD.getCurrentUser(); return u ? JSON.parse(localStorage.getItem('ld_wish_' + u.id) || '[]') : []; },
  toggleWish(id)    {
    const u = LD.getCurrentUser(); if (!u) return false;
    let w = LD.getWishlist();
    const idx = w.indexOf(id);
    idx > -1 ? w.splice(idx, 1) : w.push(id);
    localStorage.setItem('ld_wish_' + u.id, JSON.stringify(w));
    return idx === -1; // true = added
  },

  /* ── TEST DRIVES ── */
  getTestDrives()   { return JSON.parse(localStorage.getItem('ld_td') || '[]'); },
  addTestDrive(td)  { const a = LD.getTestDrives(); a.push(td); localStorage.setItem('ld_td', JSON.stringify(a)); },

  /* ── SELL ENQUIRIES ── */
  getSellEnquiries()   { return JSON.parse(localStorage.getItem('ld_sell') || '[]'); },
  addSellEnquiry(e)    { const a = LD.getSellEnquiries(); a.push(e); localStorage.setItem('ld_sell', JSON.stringify(a)); },

  /* ── CONTACT MSGS ── */
  getContacts()     { return JSON.parse(localStorage.getItem('ld_contacts') || '[]'); },
  addContact(c)     { const a = LD.getContacts(); a.push(c); localStorage.setItem('ld_contacts', JSON.stringify(a)); },
};

/* ── INIT DATA ── */
LD.initCars();

/* ═══════ AUTH GUARD ═══════
   Call this on any page that requires login.
   Pages that DON'T require login: login.html, register.html
   Every other page redirects to login if not authenticated.
*/
function requireAuth() {
  const publicPages = ['login.html', 'register.html'];
  const currentPage = location.pathname.split('/').pop() || 'index.html';
  if (publicPages.some(p => currentPage.endsWith(p))) return; // allow public pages
  if (!LD.getCurrentUser()) {
    sessionStorage.setItem('ld_redirect', location.href); // remember where they wanted to go
    window.location.replace('login.html');
  }
}
requireAuth(); // runs immediately on every page load

/* ═══════ NAVBAR BUILDER ═══════ */
function buildNav(activePage) {
  const user = LD.getCurrentUser();
  const pages = [
    { href: 'index.html',   label: 'Home' },
    { href: 'buy.html',     label: 'Buy' },
    { href: 'sell.html',    label: 'Sell' },
    { href: 'showroom.html',label: 'Showroom' },
    { href: 'about.html',   label: 'About Us' },
    { href: 'contact.html', label: 'Contact' },
  ];
  let linksHTML = pages.map(p =>
    `<li class="nav-item">
      <a class="nav-link ${p.label === activePage ? 'active-page' : ''}" href="${p.href}">${p.label}</a>
    </li>`
  ).join('');

  let userHTML = user
    ? `<div class="nav-user-info d-none d-lg-flex">
        <div class="nav-avatar">${user.name.charAt(0).toUpperCase()}</div>
        <span style="color:var(--white);font-size:.8rem">Hi, <strong style="color:var(--gold)">${user.name.split(' ')[0]}</strong></span>
       </div>
       <a href="profile.html" class="nav-user-btn nav-link ms-2">My Account</a>
       <a href="#" id="logoutBtn" class="btn-dark-outline ms-2" style="padding:.35rem .9rem;font-size:.72rem">Logout</a>`
    : `<a href="login.html" class="nav-link ms-2" style="color:rgba(255,255,255,.65)">Login</a>
       <a href="register.html" class="nav-user-btn nav-link">Register</a>`;

  document.getElementById('navPlaceholder').innerHTML = `
  <nav class="navbar navbar-expand-lg" id="mainNav">
    <div class="container">
      <a class="navbar-brand" href="index.html">Lux<span>Drive</span><small>Premium Motors</small></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navMenu">
        <ul class="navbar-nav mx-auto gap-1">${linksHTML}</ul>
        <div class="d-flex align-items-center gap-1 mt-2 mt-lg-0">${userHTML}</div>
      </div>
    </div>
  </nav>`;

  document.getElementById('logoutBtn')?.addEventListener('click', e => {
    e.preventDefault(); LD.logout(); window.location.href = 'index.html';
  });

  window.addEventListener('scroll', () => {
    document.getElementById('mainNav')?.classList.toggle('scrolled', window.scrollY > 60);
  });
}

/* ═══════ FOOTER BUILDER ═══════ */
function buildFooter() {
  const el = document.getElementById('footerPlaceholder');
  if (!el) return;
  el.innerHTML = `
  <footer>
    <div class="container">
      <div class="row g-5">
        <div class="col-lg-4">
          <div class="footer-logo">Lux<span>Drive</span><small>Premium Motors</small></div>
          <p class="footer-tagline">India's finest luxury pre-owned car marketplace</p>
          <div class="footer-social">
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
            <a href="#"><i class="fab fa-whatsapp"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
          </div>
        </div>
        <div class="col-lg-2 col-6">
          <div class="footer-h">Navigate</div>
          <a class="footer-link" href="index.html">Home</a>
          <a class="footer-link" href="buy.html">Buy a Car</a>
          <a class="footer-link" href="sell.html">Sell Your Car</a>
          <a class="footer-link" href="showroom.html">Showroom</a>
          <a class="footer-link" href="about.html">About Us</a>
        </div>
        <div class="col-lg-2 col-6">
          <div class="footer-h">Explore</div>
          <a class="footer-link" href="buy.html?type=supercar">Supercars</a>
          <a class="footer-link" href="buy.html?type=suv">Luxury SUVs</a>
          <a class="footer-link" href="buy.html?type=sedan">Sedans</a>
          <a class="footer-link" href="contact.html">Finance Enquiry</a>
          <a class="footer-link" href="contact.html">Test Drive</a>
        </div>
        <div class="col-lg-4">
          <div class="footer-h">Visit Us</div>
          <p class="footer-link" style="cursor:default">
            <i class="fas fa-map-marker-alt text-gold me-2"></i>LuxDrive House,  150 Ft Ring Road, Rajkot – 360005  
          </p>
          <p class="footer-link" style="cursor:default">
            <i class="fas fa-phone-alt text-gold me-2"></i>
            <a href="tel:+918888888888" style="color:inherit;text-decoration:none">+91 88888 88888</a>
          </p>
          <p class="footer-link" style="cursor:default">
            <i class="fas fa-envelope text-gold me-2"></i>
            <a href="mailto:hello@luxdrive.in" style="color:inherit;text-decoration:none">hello@luxdrive.in</a>
          </p>
          <p class="footer-link" style="cursor:default">
            <i class="fas fa-clock text-gold me-2"></i>Mon – Sun &nbsp; 9:00 AM – 8:00 PM
          </p>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; 2026 LuxDrive Motors Pvt. Ltd. All rights reserved.</p>
        <p>
          <a href="#" class="footer-link d-inline" style="padding:0;margin-right:1rem">Privacy Policy</a>
          <a href="#" class="footer-link d-inline" style="padding:0">Terms &amp; Conditions</a>
        </p>
      </div>
    </div>
  </footer>
  <!-- CHATBOT -->
  <div id="chatbotWrap">
    <button id="chatToggle" title="Chat with LuxDrive AI">
      <i class="fas fa-comment-dots" id="chatIcon"></i>
      <span class="chat-badge" id="chatBadge" style="display:none">1</span>
    </button>
    <div id="chatWindow">
      <div id="chatHeader">
        <div style="display:flex;align-items:center;gap:.7rem">
          <div style="width:36px;height:36px;border-radius:50%;background:var(--gold);color:var(--black);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:.9rem;flex-shrink:0">LD</div>
          <div>
            <div style="font-family:'Playfair Display',serif;font-weight:700;font-size:.9rem;color:var(--white)">LuxDrive Concierge</div>
            <div style="font-size:.68rem;color:#4caf50;letter-spacing:1px">● Online Now</div>
          </div>
        </div>
        <button id="chatClose"><i class="fas fa-times"></i></button>
      </div>
      <div id="chatMessages"></div>
      <div id="chatQuickReplies"></div>
      <div id="chatInputRow">
        <input type="text" id="chatInput" placeholder="Type your message..." autocomplete="off">
        <button id="chatSend"><i class="fas fa-paper-plane"></i></button>
      </div>
    </div>
  </div>`;
  /* ── init chatbot AFTER HTML is in DOM ── */
  initChatbot();
}

/* ═══════ TOAST ═══════ */
function showToast(msg, type = 'gold') {
  let t = document.getElementById('ldToast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'ldToast'; t.className = 'lux-toast';
    document.body.appendChild(t);
  }
  t.style.borderLeftColor = type === 'red' ? 'var(--red)' : type === 'green' ? '#1e7a3e' : 'var(--gold)';
  t.innerHTML = msg;
  t.classList.add('visible');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('visible'), 3200);
}

/* ═══════ SCROLL REVEAL ═══════ */
function initReveal() {
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('show'); });
  }, { threshold: 0.1 });
  document.querySelectorAll('.reveal, .reveal-left, .reveal-right').forEach(el => obs.observe(el));
}
document.addEventListener('DOMContentLoaded', initReveal);

/* ═══════ COUNTER ANIMATE ═══════ */
function animCount(el, target, suffix = '') {
  let n = 0, step = Math.ceil(target / 55);
  const t = setInterval(() => {
    n = Math.min(n + step, target);
    el.textContent = n + suffix;
    if (n >= target) clearInterval(t);
  }, 22);
}

/* ═══════ CAR CARD RENDERER ═══════ */
function carCardHTML(c) {
  const wish = LD.getWishlist();
  const wished = wish.includes(c.id);
  const priceStr = c.price ? `₹${parseFloat(c.price).toFixed(2)} Cr` : 'Price on Request';
  const badgeMap = { featured:'badge-featured', new:'badge-new', sold:'badge-sold' };
  const badgeClass = badgeMap[c.badge] || '';
  const badgeLabel = c.badge ? c.badge.charAt(0).toUpperCase() + c.badge.slice(1) : '';
  const ownerBadge = c.owner !== 'admin' ? '<span class="card-badge badge-user">User Listed</span>' : '';
  const imgs = c.imgs || (c.img ? [c.img] : ['https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80']);
  const uid = 'cc_' + c.id;
  const cityTag = c.city ? `<div class="card-city-tag"><i class="fas fa-map-marker-alt"></i>${c.city}</div>` : '';

  // Build carousel slides
  const slides = imgs.map((src,i) => `
    <div class="car-slide ${i===0?'active':''}">
      <img src="${src}" alt="${c.brand} ${c.model}" loading="lazy"
        onerror="this.src='https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80'">
    </div>`).join('');

  const dots = imgs.length > 1 ? `<div class="slide-dots">
    ${imgs.map((_,i)=>`<span class="slide-dot ${i===0?'active':''}" data-idx="${i}"></span>`).join('')}
  </div>` : '';

  const arrows = imgs.length > 1 ? `
    <button class="slide-arrow slide-prev" data-uid="${uid}"><i class="fas fa-chevron-left"></i></button>
    <button class="slide-arrow slide-next" data-uid="${uid}"><i class="fas fa-chevron-right"></i></button>` : '';

  const photoCount = imgs.length > 1 ? `<div class="photo-count"><i class="fas fa-camera"></i>${imgs.length}</div>` : '';

  return `
  <div class="car-card h-100">
    <div class="car-card-img-wrap" id="${uid}">
      <div class="car-carousel">${slides}</div>
      ${arrows}
      ${dots}
      ${badgeClass ? `<span class="card-badge ${badgeClass}">${badgeLabel}</span>` : ownerBadge}
      ${photoCount}
      <button class="btn-wish ${wished?'on':''}" data-id="${c.id}" title="Wishlist">
        <i class="${wished?'fas':'far'} fa-heart"></i>
      </button>
    </div>
    <div class="car-card-body">
      ${cityTag}
      <div class="car-brand-tag">${c.brand}</div>
      <div class="car-title">${c.model} <span style="color:var(--gray);font-family:'Barlow',sans-serif;font-weight:400;font-size:.8rem">${c.year}</span></div>
      <div class="car-specs-row">
        <span><i class="fas fa-road car-spec"></i>${c.km} km</span>
        <span><i class="fas fa-gas-pump car-spec"></i>${c.fuel}</span>
        <span><i class="fas fa-cog car-spec"></i>${c.trans}</span>
      </div>
      <div class="car-price-bar">
        <span class="car-price">${priceStr}</span>
        <button class="card-action-btn view-car-btn" data-id="${c.id}">Details</button>
      </div>
    </div>
  </div>`;
}

/* ═══════ CAR DETAIL MODAL ═══════ */
function openCarModal(id) {
  const c = LD.getCars().find(x => x.id === id);
  if (!c) return;
  const user = LD.getCurrentUser();
  const priceStr = c.price ? `₹${parseFloat(c.price).toFixed(2)} Crore` : 'Price on Request';
  const imgs = c.imgs || (c.img ? [c.img] : ['https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=800&q=80']);

  document.getElementById('carModalTitle').textContent = `${c.brand} ${c.model}`;
  document.getElementById('carModalBrand').textContent = c.brand;
  document.getElementById('carModalName').textContent = `${c.model} (${c.year})`;
  document.getElementById('carModalPrice').textContent = priceStr;
  document.getElementById('carModalDesc').textContent = c.desc || '';

  // ── Photo gallery (main + thumbnails)
  document.getElementById('carModalMainImg').src = imgs[0];
  document.getElementById('carModalMainImg').alt = `${c.brand} ${c.model}`;
  const thumbWrap = document.getElementById('carModalThumbs');
  thumbWrap.innerHTML = imgs.map((src,i) => `
    <img src="${src}" data-full="${src}" class="modal-thumb ${i===0?'active':''}"
      alt="Photo ${i+1}" onerror="this.style.display='none'">`).join('');

  // ── Specs
  document.getElementById('carModalSpecs').innerHTML = `
    <div class="spec-item"><div class="spec-lbl">Odometer</div><div class="spec-val">${c.km} km</div></div>
    <div class="spec-item"><div class="spec-lbl">Fuel</div><div class="spec-val">${c.fuel}</div></div>
    <div class="spec-item"><div class="spec-lbl">Transmission</div><div class="spec-val">${c.trans}</div></div>
    <div class="spec-item"><div class="spec-lbl">Power</div><div class="spec-val">${c.power || '—'}</div></div>
    <div class="spec-item"><div class="spec-lbl">Colour</div><div class="spec-val">${c.color || '—'}</div></div>
    <div class="spec-item"><div class="spec-lbl">Type</div><div class="spec-val" style="text-transform:capitalize">${c.type}</div></div>
  `;

  // ── City availability
  const cityHTML = c.city ? `
    <div class="modal-city-row">
      <div class="modal-city-item">
        <div class="modal-city-lbl"><i class="fas fa-map-marker-alt"></i> Car Location</div>
        <div class="modal-city-val">${c.city}</div>
      </div>
      ${c.testDriveCities && c.testDriveCities.length ? `
      <div class="modal-city-item">
        <div class="modal-city-lbl"><i class="fas fa-car"></i> Test Drive Available In</div>
        <div class="modal-city-tags">${c.testDriveCities.map(ct=>`<span class="td-city-tag">${ct}</span>`).join('')}</div>
      </div>` : ''}
    </div>` : '';
  document.getElementById('carModalCityInfo').innerHTML = cityHTML;

  // ── Test drive prefill
  document.getElementById('tdCarName').value = `${c.brand} ${c.model} (${c.year})`;
  document.getElementById('tdCarId').value = c.id;
  // populate test drive city dropdown
  const tdCitySelect = document.getElementById('tdCity');
  if (tdCitySelect) {
    tdCitySelect.innerHTML = '';
    const cities = c.testDriveCities && c.testDriveCities.length ? c.testDriveCities : ['Rajkot, Gujarat','Ahmedabad, Gujarat','Dubai, UAE'];
    cities.forEach(ct => { const o=document.createElement('option'); o.value=ct; o.textContent=ct; tdCitySelect.appendChild(o); });
  }
  if (user) {
    document.getElementById('tdName').value = user.name;
    document.getElementById('tdPhone').value = user.phone || '';
  }
  new bootstrap.Modal('#carModal').show();
}

/* ═══════ GLOBAL DELEGATION ═══════ */
document.addEventListener('click', e => {
  // wishlist
  const wb = e.target.closest('.btn-wish');
  if (wb) {
    const u = LD.getCurrentUser();
    if (!u) { showToast('⚠️ Please login to save to wishlist'); window.location.href='login.html'; return; }
    const id = wb.dataset.id;
    const added = LD.toggleWish(id);
    wb.classList.toggle('on', added);
    wb.innerHTML = `<i class="${added ? 'fas' : 'far'} fa-heart"></i>`;
    showToast(added ? '❤️ Added to wishlist' : 'Removed from wishlist');
  }
  // view car detail
  const vb = e.target.closest('.view-car-btn');
  if (vb) openCarModal(vb.dataset.id);

  // carousel prev/next
  const prevBtn = e.target.closest('.slide-prev');
  const nextBtn = e.target.closest('.slide-next');
  const arrowBtn = prevBtn || nextBtn;
  if (arrowBtn) {
    e.stopPropagation();
    const uid = arrowBtn.dataset.uid;
    const wrap = document.getElementById(uid);
    if (!wrap) return;
    const slides = wrap.querySelectorAll('.car-slide');
    const dots   = wrap.querySelectorAll('.slide-dot');
    let cur = [...slides].findIndex(s => s.classList.contains('active'));
    slides[cur].classList.remove('active');
    dots[cur]?.classList.remove('active');
    if (prevBtn) cur = (cur - 1 + slides.length) % slides.length;
    else         cur = (cur + 1) % slides.length;
    slides[cur].classList.add('active');
    dots[cur]?.classList.add('active');
  }

  // slide dots
  const dot = e.target.closest('.slide-dot');
  if (dot) {
    e.stopPropagation();
    const wrap = dot.closest('.car-card-img-wrap');
    if (!wrap) return;
    const idx = parseInt(dot.dataset.idx);
    wrap.querySelectorAll('.car-slide').forEach((s,i) => s.classList.toggle('active', i===idx));
    wrap.querySelectorAll('.slide-dot').forEach((d,i) => d.classList.toggle('active', i===idx));
  }

  // modal thumbnails
  const thumb = e.target.closest('.modal-thumb');
  if (thumb) {
    document.getElementById('carModalMainImg').src = thumb.dataset.full;
    document.querySelectorAll('.modal-thumb').forEach(t => t.classList.remove('active'));
    thumb.classList.add('active');
  }
});

/* ═══════════════════════════════════════════════════
   CHATBOT ENGINE — LuxDrive AI Concierge
   ═══════════════════════════════════════════════════ */
function initChatbot() {
  const toggle   = document.getElementById('chatToggle');
  const win      = document.getElementById('chatWindow');
  const closeBtn = document.getElementById('chatClose');
  const msgs     = document.getElementById('chatMessages');
  const input    = document.getElementById('chatInput');
  const sendBtn  = document.getElementById('chatSend');
  const qrArea   = document.getElementById('chatQuickReplies');
  const badge    = document.getElementById('chatBadge');
  if (!toggle) return;

  let isOpen = false;
  let awaitingContext = null;

  /* ── knowledge base ── */
  const user = LD.getCurrentUser();
  const userName = user ? user.name.split(' ')[0] : 'there';

  const KB = [
    { keys:['hello','hi','hey','helo','namaste'],
      reply: `Hey ${userName}! 👋 Welcome to LuxDrive's AI Concierge. I can help you with:\n• Finding the perfect car\n• Test drive bookings\n• Sell / valuation queries\n• Showroom locations\n• Finance & EMI info\n\nWhat can I do for you today?`,
      qr:['Browse Cars','Sell My Car','Showroom Locations','Book Test Drive'] },

    { keys:['buy','browse','find car','looking for','search','inventory','available'],
      reply:'We have a stunning collection of supercars, luxury SUVs, and sedans — all certified.\n\n🔗 Head to our <a href="buy.html" style="color:var(--gold)">Buy page</a> to explore the full inventory with filters.',
      qr:['Supercars','Luxury SUVs','Under ₹3 Cr','Book Test Drive'] },

    { keys:['supercar','lamborghini','ferrari','mclaren','porsche','sports'],
      reply:'Our supercar lineup includes Lamborghini Huracán EVO, Ferrari Roma, Porsche 911 GT3, McLaren 720S and more — all with full service history.\n\n🔗 <a href="buy.html?type=supercar" style="color:var(--gold)">View all Supercars →</a>',
      qr:['Price Range','Book Test Drive','Finance Options'] },

    { keys:['suv','bentayga','g63','cayenne','g wagon','bentley','mercedes'],
      reply:'Our luxury SUVs include Bentley Bentayga S, Mercedes-AMG G63, Porsche Cayenne Turbo GT and more — all in pristine condition.\n\n🔗 <a href="buy.html?type=suv" style="color:var(--gold)">View all SUVs →</a>',
      qr:['Price Range','Book Test Drive','Finance Options'] },

    { keys:['rolls','ghost','phantom','sedan'],
      reply:'Our sedan collection features the Rolls-Royce Ghost EWB, BMW M8 Competition and more bespoke luxury saloons.\n\n🔗 <a href="buy.html?type=sedan" style="color:var(--gold)">View all Sedans →</a>',
      qr:['Book Test Drive','Showroom Visit'] },

    { keys:['sell','valuation','value my car','want to sell','my car'],
      reply:'Great! We offer the best prices for your luxury car. Here\'s how it works:\n\n1️⃣ Submit car details\n2️⃣ Free home inspection\n3️⃣ Instant price offer\n4️⃣ Same-day payment\n\n🔗 <a href="sell.html" style="color:var(--gold)">Get Your Free Valuation →</a>',
      qr:['What cars do you buy?','How long does it take?','Showroom Locations'] },

    { keys:['what car','which car','accept','take car','buy car'],
      reply:'We buy all premium brands including Lamborghini, Ferrari, Porsche, Rolls-Royce, Bentley, McLaren, BMW, Mercedes-Benz, Audi, Bugatti and more.\n\nMinimum value threshold: ₹50 Lakh.',
      qr:['Get Valuation','Contact Us'] },

    { keys:['test drive','drive','try','test'],
      reply:`Love it! 🚗 You can book a test drive directly from any car's detail page.\n\nTest drives available at:\n• Rajkot, Gujarat\n• Ahmedabad, Gujarat\n• Dubai, UAE\n\n🔗 <a href="buy.html" style="color:var(--gold)">Pick a car & book →</a>`,
      qr:['Showroom Locations','Contact Us'] },

    { keys:['showroom','location','visit','where','address','city','rajkot','ahmedabad','dubai'],
      reply:'🏢 We have 3 showroom locations:\n\n📍 <strong style="color:var(--gold)">Rajkot, Gujarat</strong>\n&nbsp;&nbsp;&nbsp;Galaxy Motors Complex, 150 Ft Ring Rd\n\n📍 <strong style="color:var(--gold)">Ahmedabad, Gujarat</strong>\n&nbsp;&nbsp;&nbsp;SG Highway, Prahlad Nagar\n\n🌍 <strong style="color:var(--gold)">Dubai, UAE</strong>\n&nbsp;&nbsp;&nbsp;Sheikh Zayed Rd, Business Bay\n\n🔗 <a href="showroom.html" style="color:var(--gold)">Full Showroom Details →</a>',
      qr:['Book Appointment','Contact Us','Opening Hours'] },

    { keys:['timing','hour','open','close','time','when'],
      reply:'🕘 Our showroom hours:\n\n• Monday – Friday: 9:00 AM – 8:00 PM\n• Saturday: 9:00 AM – 8:00 PM\n• Sunday: 10:00 AM – 6:00 PM\n\nAll locations. Dubai follows GST timezone.',
      qr:['Showroom Locations','Book Appointment'] },

    { keys:['finance','emi','loan','bank','interest','monthly'],
      reply:'💳 LuxDrive Finance Options:\n\n• 15+ banking partners\n• EMI from 0% interest (select schemes)\n• Loan approval in 48 hours\n• Minimal documentation required\n• Amount: ₹50L – ₹10 Crore\n\nSpeak to our finance desk: <a href="tel:+918888888888" style="color:var(--gold)">+91 88888 88888</a>',
      qr:['Contact Finance Desk','Visit Showroom'] },

    { keys:['price','cost','how much','crore','lakh','budget'],
      reply:'Our inventory ranges from ₹80 Lakhs to ₹12+ Crore.\n\n🔍 Use filters on the <a href="buy.html" style="color:var(--gold)">Buy page</a> to sort by budget.\n\nNeed help finding something specific? Tell me your budget!',
      qr:['Under ₹2 Cr','₹2–5 Cr','Above ₹5 Cr'] },

    { keys:['under 2','below 2','less than 2','₹1','₹2','2 crore','budget 2'],
      reply:'Cars under ₹2 Crore include BMW M8 Competition (₹2.1 Cr) and select Porsche models. Check the full range:\n🔗 <a href="buy.html" style="color:var(--gold)">Browse Inventory →</a>',
      qr:['Book Test Drive','Finance Options'] },

    { keys:['above 5','luxury','5 crore','rolls royce','bentley price'],
      reply:'Our ultra-luxury range (₹5 Cr+) includes Rolls-Royce Ghost EWB (₹7.2 Cr) and Bentley Bentayga S (₹5.5 Cr).\n🔗 <a href="buy.html" style="color:var(--gold)">View Premium Collection →</a>',
      qr:['Book Test Drive','Private Viewing'] },

    { keys:['private','vip','exclusive','viewing','appointment'],
      reply:'🥂 We offer private viewing appointments at all showrooms with:\n• Dedicated relationship manager\n• Espresso & hospitality\n• No time pressure\n\n🔗 <a href="showroom.html" style="color:var(--gold)">Book a Private Appointment →</a>',
      qr:['Showroom Locations','Contact Us'] },

    { keys:['delivery','ship','transport','send'],
      reply:'🚛 Pan-India delivery available!\n\n• Enclosed car carriers\n• Full insurance in transit\n• GPS tracked delivery\n• 3–7 days to major cities\n• White-glove handover\n\nDelivery charges vary by distance.',
      qr:['Contact Us','More Info'] },

    { keys:['paper','rc','insurance','noc','transfer','document'],
      reply:'📄 We handle ALL paperwork:\n✅ RC Transfer\n✅ Insurance Transfer\n✅ NOC from finance\n✅ Form 28, 29, 30\n\nTypically completed within 7 working days after sale.',
      qr:['Contact Us','Visit Showroom'] },

    { keys:['contact','phone','call','email','whatsapp','number'],
      reply:'📞 Reach us anytime:\n\n<strong style="color:var(--gold)">Call:</strong> <a href="tel:+918888888888" style="color:var(--gold)">+91 88888 88888</a>\n<strong style="color:var(--gold)">Email:</strong> hello@luxdrive.in\n<strong style="color:var(--gold)">WhatsApp:</strong> +91 88888 88888\n\n🔗 <a href="contact.html" style="color:var(--gold)">Contact Page →</a>',
      qr:['Showroom Locations','Book Appointment'] },

    { keys:['thank','thanks','ok','okay','great','awesome','perfect'],
      reply:`You\'re most welcome, ${userName}! 😊 Is there anything else I can help you with today?`,
      qr:['Browse Cars','Showroom Locations','Contact Us'] },

    { keys:['bye','goodbye','no thanks','nothing','done'],
      reply:`Goodbye, ${userName}! 🙏 It was a pleasure. Feel free to chat again anytime. Happy driving! 🏎️`,
      qr:[] },
  ];

  const DEFAULT_REPLY = `I'm not sure about that, but I'd love to help! Try one of these topics or call us at <a href="tel:+918888888888" style="color:var(--gold)">+91 88888 88888</a>.`;
  const DEFAULT_QR = ['Browse Cars','Showroom Locations','Finance Options','Contact Us'];

  /* ── toggle open/close ── */
  function openChat() {
    isOpen = true;
    win.classList.add('open');
    badge.style.display = 'none';
    if (msgs.children.length === 0) {
      setTimeout(() => botReply(`Hey ${userName}! 👋 I'm LuxDrive's AI Concierge. How can I help you today?`, ['Browse Cars','Sell My Car','Showroom Locations','Book Test Drive']), 300);
    }
    setTimeout(() => input.focus(), 350);
  }
  function closeChat() {
    isOpen = false;
    win.classList.remove('open');
  }

  toggle.addEventListener('click', () => isOpen ? closeChat() : openChat());
  closeBtn.addEventListener('click', closeChat);

  /* ── messaging ── */
  function addMsg(text, who) {
    const div = document.createElement('div');
    div.className = `chat-msg ${who}`;
    div.innerHTML = text;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function showTyping() {
    const t = document.createElement('div');
    t.className = 'chat-typing'; t.id = 'chatTyping';
    t.innerHTML = '<span></span><span></span><span></span>';
    msgs.appendChild(t);
    msgs.scrollTop = msgs.scrollHeight;
  }
  function hideTyping() {
    document.getElementById('chatTyping')?.remove();
  }

  function setQR(qrs) {
    qrArea.innerHTML = '';
    (qrs || []).forEach(q => {
      const b = document.createElement('button');
      b.className = 'qr-btn'; b.textContent = q;
      b.addEventListener('click', () => handleSend(q));
      qrArea.appendChild(b);
    });
  }

  function botReply(text, qrs, delay = 900) {
    showTyping();
    setTimeout(() => {
      hideTyping();
      addMsg(text, 'bot');
      setQR(qrs);
    }, delay);
  }

  function handleSend(text) {
    const q = (text || input.value).trim();
    if (!q) return;
    addMsg(q, 'user');
    input.value = '';
    setQR([]);

    const lower = q.toLowerCase();
    const match = KB.find(k => k.keys.some(kw => lower.includes(kw)));
    if (match) {
      botReply(match.reply, match.qr);
    } else {
      botReply(DEFAULT_REPLY, DEFAULT_QR);
    }
  }

  sendBtn.addEventListener('click', () => handleSend());
  input.addEventListener('keydown', e => { if (e.key === 'Enter') handleSend(); });

  /* ── show badge after 3s ── */
  setTimeout(() => { badge.style.display = 'flex'; }, 3000);
}
